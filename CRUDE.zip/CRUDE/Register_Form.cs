﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace CRUDE
{
    public partial class Register_Form : Form
    {
        public Register_Form()
        {
            InitializeComponent();
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            runQuery();
        }

        private void runQuery()
        {
            string query = "INSERT INTO studentdata(student_id, first_name, middle_name, last_name, suffix, age, gender, address, contact_Number, course , yearlevel,Section) VALUES " +
                "('" + TbxStudent_Id.Text + "','" + TbxFName.Text +"','" + TbxMName.Text + "','" + TbxLName.Text + "','" + CbxSuffix.Text + "','" + TbxAge.Text + "','" + CbxGender.Text + "','" +TbxAddress.Text + "','" +TbxContact_Num.Text + "','" +TbxCourse.Text + "','" + CbxYear_Level.Text  +"','" +TbxSection.Text+ "')";
            MySqlConnection connect = new MySqlConnection(Connection.ConnectionString);
            MySqlCommand command = new MySqlCommand(query,connect);
            command.CommandTimeout = 60;

            try
            {
                connect.Open();

                MySqlDataReader reader = command.ExecuteReader();

                if (reader.HasRows)
                {
                }
                else
                {
                    MessageBox.Show("Informarion have been Saved");
                    TbxStudent_Id.Clear();
                    TbxFName.Clear();
                    TbxMName.Clear();
                    TbxLName.Clear();
                    CbxSuffix.ResetText();                   
                    TbxAge.Clear();
                    CbxGender.ResetText();
                    TbxAddress.Clear();
                    TbxContact_Num.Clear();
                    TbxCourse.Clear();
                    CbxYear_Level.ResetText();
                    TbxSection.Clear();
                }

            }
            catch (Exception e)
            {
                MessageBox.Show("Query error: " + e.Message);
            }
        }

        private void bACKToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Main_Form mf = new Main_Form();
            this.Hide();
            mf.Show();
        }
    }
}
