﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace CRUDE
{
    internal class Connection
    {
        public static string ConnectionString = "datasource = 127.0.0.1;port = 3306; username =root; password=; database = studentinformation";
        public static string IdContent = "";
        public static bool check = false;

    }
}
