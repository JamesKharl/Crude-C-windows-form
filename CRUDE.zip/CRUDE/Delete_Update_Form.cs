﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace CRUDE
{
    public partial class Delete_Update_Form : Form
    {
        public Delete_Update_Form()
        {
            InitializeComponent();
        }

        private void Delete_Update_Form_Load(object sender, EventArgs e)
        {
            string query = "SELECT * FROM studentdata WHERE student_id = '" + Connection.IdContent +"'";

            using (MySqlConnection connect = new MySqlConnection(Connection.ConnectionString))
            {
                using (MySqlCommand command = new MySqlCommand(query, connect))
                {
                   // command.Parameters.AddWithValue("@StudentId", Connection.IdContent);
                    command.CommandTimeout = 60;

                    try
                    {
                        connect.Open();

                        using (MySqlDataReader reader = command.ExecuteReader())
                        {
                            if (reader.HasRows)
                            {
                                while (reader.Read())
                                {
                                    TbxStudent_Id.Text = reader.GetString(0);
                                    TbxFName.Text = reader.GetString(1);
                                    TbxMName.Text = reader.GetString(2);
                                    TbxLName.Text = reader.GetString(3);
                                    CbxSuffix.Text = reader.GetString(4);
                                    TbxAge.Text = reader.GetString(5);
                                    CbxGender.Text = reader.GetString(6);
                                    TbxAddress.Text = reader.GetString(7);
                                    TbxContact_Num.Text = reader.GetString(8);
                                    TbxCourse.Text = reader.GetString(9);
                                    CbxYear_Level.Text = reader.GetString(10);
                                    TbxSection.Text = reader.GetString(11);
                                }
                            }
                        }
                    }
                    catch (Exception x)
                    {
                        MessageBox.Show("Query error: " + x.Message);
                    }
                }
            } 


        }

        private void BtnUpdate_Click(object sender, EventArgs e)
        {
            string query = "UPDATE  studentdata  SET  student_id = '" + TbxStudent_Id.Text + "', first_name = '" + TbxFName.Text + "', middle_name = '" + TbxMName.Text + "', last_name = '" + TbxLName.Text + "', suffix = '" + CbxSuffix.Text
                           + "', age = '" + TbxAge.Text + "', gender = '" + CbxGender.Text + "', address = '" + TbxAddress.Text + "', contact_Number = '" + TbxContact_Num.Text + "', course = '" + TbxCourse.Text + "', yearlevel = '" + CbxYear_Level.Text + "', Section = '" + TbxSection.Text + "' WHERE student_id = '" + Connection.IdContent + "'";
            MySqlConnection connect = new MySqlConnection(Connection.ConnectionString);
            MySqlCommand command = new MySqlCommand(query, connect);
            command.CommandTimeout = 60;

            try
            {
                connect.Open();

                MySqlDataReader reader = command.ExecuteReader();

                if (reader.HasRows)
                {
                }
                else
                {
                    MessageBox.Show("Informarion have been Updated");
                    TbxStudent_Id.Clear();
                    TbxFName.Clear();
                    TbxMName.Clear();
                    TbxLName.Clear();
                    CbxSuffix.ResetText();
                    TbxAge.Clear();
                    CbxGender.ResetText();
                    TbxAddress.Clear();
                    TbxContact_Num.Clear();
                    TbxCourse.Clear();
                    CbxYear_Level.ResetText();
                    TbxSection.Clear();

                    View_Form vf = new View_Form();
                    this.Hide();
                    vf.Show();

                }

            }
            catch (Exception c)
            {
                MessageBox.Show("Query error: " + c.Message);
            }
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            string query = "DELETE FROM studentdata WHERE student_id = '" + Connection.IdContent + "'";
            MySqlConnection connect = new MySqlConnection(Connection.ConnectionString);
            MySqlCommand command = new MySqlCommand(query, connect);
            command.CommandTimeout = 60;

            try
            {
                connect.Open();

                MySqlDataReader reader = command.ExecuteReader();

                if (reader.HasRows)
                {
                }
                else
                {
                    MessageBox.Show("Informarion have been Deleted");
                    TbxStudent_Id.Clear();
                    TbxFName.Clear();
                    TbxMName.Clear();
                    TbxLName.Clear();
                    CbxSuffix.ResetText();
                    TbxAge.Clear();
                    CbxGender.ResetText();
                    TbxAddress.Clear();
                    TbxContact_Num.Clear();
                    TbxCourse.Clear();
                    CbxYear_Level.ResetText();
                    TbxSection.Clear();

                    View_Form vf = new View_Form();
                    this.Hide();
                    vf.Show();
                }

            }
            catch (Exception b)
            {
                MessageBox.Show("Query error: " + b.Message);
            }
        }

        private void bACKToolStripMenuItem_Click(object sender, EventArgs e)
        {
            View_Form vf = new View_Form();
            this.Hide();
            vf.Show();
        }
    }
}
