﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CRUDE
{
    public partial class Main_Form : Form
    {
        public Main_Form()
        {
            InitializeComponent();
        }

        private void BtnAddStudent_Click(object sender, EventArgs e)
        {
            Register_Form rf = new Register_Form();
            this.Hide();
            rf.Show();
        }

        private void BtnView_Click(object sender, EventArgs e)
        {
            View_Form vf = new View_Form();
            this.Hide();
            vf.Show();
        }
    }
}
