﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace CRUDE
{
    public partial class View_Form : Form
    {
        public View_Form()
        {
            InitializeComponent();
        }

        private void View_Form_Load(object sender, EventArgs e)
        {
            string[] columnNames = new string[] { "Student Id", "First Name", "Middle Name", "Last Name", "Suffix","Age","Gender","Address" , "Contact Number","Course" , "Year Level" , "Section" };

            DGVListofStudent.ColumnCount = 12;

            for (int a = 0; a < columnNames.Length; a++)
            {
                DGVListofStudent.Columns[a].Name = columnNames[a];
            }

            string query = "SELECT * FROM studentdata";
            MySqlConnection connect = new MySqlConnection(Connection.ConnectionString);
            MySqlCommand command = new MySqlCommand(query, connect);
            command.CommandTimeout = 60;

            try
            {
                connect.Open();

                MySqlDataReader reader = command.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        DGVListofStudent.Rows.Add(reader.GetString(0), reader.GetString(1), reader.GetString(2), reader.GetString(3), reader.GetString(4), reader.GetString(5), reader.GetString(6), reader.GetString(7), reader.GetString(8), reader.GetString(9), reader.GetString(10), reader.GetString(11));
                    }
                }
               
            }
            catch (Exception x)
            {
                MessageBox.Show("Query error: " + x.Message);
            }
        }

        private void bACKToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Main_Form mf = new Main_Form();
            this.Hide();
            mf.Show();
        }

        private void DGVListofStudent_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

            try
            {
                int selectedrow;
                selectedrow = e.RowIndex;
                DataGridViewRow row = DGVListofStudent.Rows[selectedrow];

                Connection.IdContent = row.Cells[0].Value.ToString();

                this.Hide();
                Delete_Update_Form duf= new Delete_Update_Form();
                duf.Show();
            }
            catch (Exception c) { MessageBox.Show(c.Message); }

        }
    }
}
