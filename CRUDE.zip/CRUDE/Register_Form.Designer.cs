﻿namespace CRUDE
{
    partial class Register_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TbxStudent_Id = new System.Windows.Forms.TextBox();
            this.LblStudent_Id = new System.Windows.Forms.Label();
            this.LblFName = new System.Windows.Forms.Label();
            this.TbxFName = new System.Windows.Forms.TextBox();
            this.LblMName = new System.Windows.Forms.Label();
            this.TbxMName = new System.Windows.Forms.TextBox();
            this.LblLName = new System.Windows.Forms.Label();
            this.TbxLName = new System.Windows.Forms.TextBox();
            this.LblSuffix = new System.Windows.Forms.Label();
            this.LblCourse = new System.Windows.Forms.Label();
            this.TbxCourse = new System.Windows.Forms.TextBox();
            this.LblContact_Num = new System.Windows.Forms.Label();
            this.TbxContact_Num = new System.Windows.Forms.TextBox();
            this.LblAddress = new System.Windows.Forms.Label();
            this.TbxAddress = new System.Windows.Forms.TextBox();
            this.LblGender = new System.Windows.Forms.Label();
            this.LblAge = new System.Windows.Forms.Label();
            this.TbxAge = new System.Windows.Forms.TextBox();
            this.LblYear_Level = new System.Windows.Forms.Label();
            this.LblSection = new System.Windows.Forms.Label();
            this.TbxSection = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.BtnSave = new System.Windows.Forms.Button();
            this.CbxSuffix = new System.Windows.Forms.ComboBox();
            this.CbxYear_Level = new System.Windows.Forms.ComboBox();
            this.CbxGender = new System.Windows.Forms.ComboBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.bACKToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // TbxStudent_Id
            // 
            this.TbxStudent_Id.Location = new System.Drawing.Point(173, 107);
            this.TbxStudent_Id.Multiline = true;
            this.TbxStudent_Id.Name = "TbxStudent_Id";
            this.TbxStudent_Id.Size = new System.Drawing.Size(177, 32);
            this.TbxStudent_Id.TabIndex = 0;
            // 
            // LblStudent_Id
            // 
            this.LblStudent_Id.AutoSize = true;
            this.LblStudent_Id.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblStudent_Id.Location = new System.Drawing.Point(70, 112);
            this.LblStudent_Id.Name = "LblStudent_Id";
            this.LblStudent_Id.Size = new System.Drawing.Size(89, 19);
            this.LblStudent_Id.TabIndex = 1;
            this.LblStudent_Id.Text = "Student Id:";
            // 
            // LblFName
            // 
            this.LblFName.AutoSize = true;
            this.LblFName.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblFName.Location = new System.Drawing.Point(70, 163);
            this.LblFName.Name = "LblFName";
            this.LblFName.Size = new System.Drawing.Size(91, 19);
            this.LblFName.TabIndex = 3;
            this.LblFName.Text = "First Name:";
            // 
            // TbxFName
            // 
            this.TbxFName.Location = new System.Drawing.Point(173, 158);
            this.TbxFName.Multiline = true;
            this.TbxFName.Name = "TbxFName";
            this.TbxFName.Size = new System.Drawing.Size(177, 32);
            this.TbxFName.TabIndex = 2;
            // 
            // LblMName
            // 
            this.LblMName.AutoSize = true;
            this.LblMName.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblMName.Location = new System.Drawing.Point(49, 213);
            this.LblMName.Name = "LblMName";
            this.LblMName.Size = new System.Drawing.Size(112, 19);
            this.LblMName.TabIndex = 5;
            this.LblMName.Text = "Middle Name: ";
            // 
            // TbxMName
            // 
            this.TbxMName.Location = new System.Drawing.Point(173, 208);
            this.TbxMName.Multiline = true;
            this.TbxMName.Name = "TbxMName";
            this.TbxMName.Size = new System.Drawing.Size(177, 32);
            this.TbxMName.TabIndex = 4;
            // 
            // LblLName
            // 
            this.LblLName.AutoSize = true;
            this.LblLName.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblLName.Location = new System.Drawing.Point(62, 260);
            this.LblLName.Name = "LblLName";
            this.LblLName.Size = new System.Drawing.Size(94, 19);
            this.LblLName.TabIndex = 7;
            this.LblLName.Text = "Last Name: ";
            // 
            // TbxLName
            // 
            this.TbxLName.Location = new System.Drawing.Point(173, 255);
            this.TbxLName.Multiline = true;
            this.TbxLName.Name = "TbxLName";
            this.TbxLName.Size = new System.Drawing.Size(177, 32);
            this.TbxLName.TabIndex = 6;
            // 
            // LblSuffix
            // 
            this.LblSuffix.AutoSize = true;
            this.LblSuffix.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblSuffix.Location = new System.Drawing.Point(102, 313);
            this.LblSuffix.Name = "LblSuffix";
            this.LblSuffix.Size = new System.Drawing.Size(60, 19);
            this.LblSuffix.TabIndex = 9;
            this.LblSuffix.Text = "Suffix: ";
            // 
            // LblCourse
            // 
            this.LblCourse.AutoSize = true;
            this.LblCourse.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblCourse.Location = new System.Drawing.Point(421, 163);
            this.LblCourse.Name = "LblCourse";
            this.LblCourse.Size = new System.Drawing.Size(69, 19);
            this.LblCourse.TabIndex = 19;
            this.LblCourse.Text = "Course: ";
            // 
            // TbxCourse
            // 
            this.TbxCourse.Location = new System.Drawing.Point(499, 158);
            this.TbxCourse.Multiline = true;
            this.TbxCourse.Name = "TbxCourse";
            this.TbxCourse.Size = new System.Drawing.Size(177, 32);
            this.TbxCourse.TabIndex = 18;
            // 
            // LblContact_Num
            // 
            this.LblContact_Num.AutoSize = true;
            this.LblContact_Num.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblContact_Num.Location = new System.Drawing.Point(388, 362);
            this.LblContact_Num.Name = "LblContact_Num";
            this.LblContact_Num.Size = new System.Drawing.Size(98, 19);
            this.LblContact_Num.TabIndex = 17;
            this.LblContact_Num.Text = "Contact No.:";
            // 
            // TbxContact_Num
            // 
            this.TbxContact_Num.Location = new System.Drawing.Point(499, 357);
            this.TbxContact_Num.Multiline = true;
            this.TbxContact_Num.Name = "TbxContact_Num";
            this.TbxContact_Num.Size = new System.Drawing.Size(177, 32);
            this.TbxContact_Num.TabIndex = 16;
            // 
            // LblAddress
            // 
            this.LblAddress.AutoSize = true;
            this.LblAddress.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblAddress.Location = new System.Drawing.Point(417, 313);
            this.LblAddress.Name = "LblAddress";
            this.LblAddress.Size = new System.Drawing.Size(72, 19);
            this.LblAddress.TabIndex = 15;
            this.LblAddress.Text = "Address:";
            // 
            // TbxAddress
            // 
            this.TbxAddress.Location = new System.Drawing.Point(499, 308);
            this.TbxAddress.Multiline = true;
            this.TbxAddress.Name = "TbxAddress";
            this.TbxAddress.Size = new System.Drawing.Size(177, 32);
            this.TbxAddress.TabIndex = 14;
            // 
            // LblGender
            // 
            this.LblGender.AutoSize = true;
            this.LblGender.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblGender.Location = new System.Drawing.Point(417, 260);
            this.LblGender.Name = "LblGender";
            this.LblGender.Size = new System.Drawing.Size(71, 19);
            this.LblGender.TabIndex = 13;
            this.LblGender.Text = "Gender: ";
            // 
            // LblAge
            // 
            this.LblAge.AutoSize = true;
            this.LblAge.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblAge.Location = new System.Drawing.Point(442, 213);
            this.LblAge.Name = "LblAge";
            this.LblAge.Size = new System.Drawing.Size(48, 19);
            this.LblAge.TabIndex = 11;
            this.LblAge.Text = "Age: ";
            // 
            // TbxAge
            // 
            this.TbxAge.Location = new System.Drawing.Point(499, 208);
            this.TbxAge.Multiline = true;
            this.TbxAge.Name = "TbxAge";
            this.TbxAge.Size = new System.Drawing.Size(177, 32);
            this.TbxAge.TabIndex = 10;
            // 
            // LblYear_Level
            // 
            this.LblYear_Level.AutoSize = true;
            this.LblYear_Level.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblYear_Level.Location = new System.Drawing.Point(70, 362);
            this.LblYear_Level.Name = "LblYear_Level";
            this.LblYear_Level.Size = new System.Drawing.Size(88, 19);
            this.LblYear_Level.TabIndex = 21;
            this.LblYear_Level.Text = "Year Level:";
            // 
            // LblSection
            // 
            this.LblSection.AutoSize = true;
            this.LblSection.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblSection.Location = new System.Drawing.Point(421, 112);
            this.LblSection.Name = "LblSection";
            this.LblSection.Size = new System.Drawing.Size(66, 19);
            this.LblSection.TabIndex = 23;
            this.LblSection.Text = "Section:";
            // 
            // TbxSection
            // 
            this.TbxSection.Location = new System.Drawing.Point(499, 107);
            this.TbxSection.Multiline = true;
            this.TbxSection.Name = "TbxSection";
            this.TbxSection.Size = new System.Drawing.Size(177, 32);
            this.TbxSection.TabIndex = 22;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(12, 63);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(221, 18);
            this.label13.TabIndex = 24;
            this.label13.Text = "Please fill up all Information";
            // 
            // BtnSave
            // 
            this.BtnSave.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnSave.Location = new System.Drawing.Point(578, 425);
            this.BtnSave.Name = "BtnSave";
            this.BtnSave.Size = new System.Drawing.Size(130, 52);
            this.BtnSave.TabIndex = 25;
            this.BtnSave.Text = "SAVE";
            this.BtnSave.UseVisualStyleBackColor = true;
            this.BtnSave.Click += new System.EventHandler(this.BtnSave_Click);
            // 
            // CbxSuffix
            // 
            this.CbxSuffix.FormattingEnabled = true;
            this.CbxSuffix.Items.AddRange(new object[] {
            "Jr.",
            "Sr.",
            "I",
            "II",
            "III",
            "N/A"});
            this.CbxSuffix.Location = new System.Drawing.Point(173, 313);
            this.CbxSuffix.Name = "CbxSuffix";
            this.CbxSuffix.Size = new System.Drawing.Size(177, 21);
            this.CbxSuffix.TabIndex = 26;
            // 
            // CbxYear_Level
            // 
            this.CbxYear_Level.FormattingEnabled = true;
            this.CbxYear_Level.Items.AddRange(new object[] {
            "1st",
            "2nd",
            "3rd",
            "4th"});
            this.CbxYear_Level.Location = new System.Drawing.Point(173, 362);
            this.CbxYear_Level.Name = "CbxYear_Level";
            this.CbxYear_Level.Size = new System.Drawing.Size(177, 21);
            this.CbxYear_Level.TabIndex = 27;
            // 
            // CbxGender
            // 
            this.CbxGender.FormattingEnabled = true;
            this.CbxGender.Items.AddRange(new object[] {
            "M",
            "F"});
            this.CbxGender.Location = new System.Drawing.Point(499, 260);
            this.CbxGender.Name = "CbxGender";
            this.CbxGender.Size = new System.Drawing.Size(177, 21);
            this.CbxGender.TabIndex = 28;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bACKToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(759, 24);
            this.menuStrip1.TabIndex = 29;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // bACKToolStripMenuItem
            // 
            this.bACKToolStripMenuItem.Name = "bACKToolStripMenuItem";
            this.bACKToolStripMenuItem.Size = new System.Drawing.Size(49, 20);
            this.bACKToolStripMenuItem.Text = "BACK";
            this.bACKToolStripMenuItem.Click += new System.EventHandler(this.bACKToolStripMenuItem_Click);
            // 
            // Register_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Cyan;
            this.ClientSize = new System.Drawing.Size(759, 487);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.CbxGender);
            this.Controls.Add(this.CbxYear_Level);
            this.Controls.Add(this.CbxSuffix);
            this.Controls.Add(this.BtnSave);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.LblSection);
            this.Controls.Add(this.TbxSection);
            this.Controls.Add(this.LblYear_Level);
            this.Controls.Add(this.LblCourse);
            this.Controls.Add(this.TbxCourse);
            this.Controls.Add(this.LblContact_Num);
            this.Controls.Add(this.TbxContact_Num);
            this.Controls.Add(this.LblAddress);
            this.Controls.Add(this.TbxAddress);
            this.Controls.Add(this.LblGender);
            this.Controls.Add(this.LblAge);
            this.Controls.Add(this.TbxAge);
            this.Controls.Add(this.LblSuffix);
            this.Controls.Add(this.LblLName);
            this.Controls.Add(this.TbxLName);
            this.Controls.Add(this.LblMName);
            this.Controls.Add(this.TbxMName);
            this.Controls.Add(this.LblFName);
            this.Controls.Add(this.TbxFName);
            this.Controls.Add(this.LblStudent_Id);
            this.Controls.Add(this.TbxStudent_Id);
            this.Name = "Register_Form";
            this.Text = "Register Form";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox TbxStudent_Id;
        private System.Windows.Forms.Label LblStudent_Id;
        private System.Windows.Forms.Label LblFName;
        private System.Windows.Forms.TextBox TbxFName;
        private System.Windows.Forms.Label LblMName;
        private System.Windows.Forms.TextBox TbxMName;
        private System.Windows.Forms.Label LblLName;
        private System.Windows.Forms.TextBox TbxLName;
        private System.Windows.Forms.Label LblSuffix;
        private System.Windows.Forms.Label LblCourse;
        private System.Windows.Forms.TextBox TbxCourse;
        private System.Windows.Forms.Label LblContact_Num;
        private System.Windows.Forms.TextBox TbxContact_Num;
        private System.Windows.Forms.Label LblAddress;
        private System.Windows.Forms.TextBox TbxAddress;
        private System.Windows.Forms.Label LblGender;
        private System.Windows.Forms.Label LblAge;
        private System.Windows.Forms.TextBox TbxAge;
        private System.Windows.Forms.Label LblYear_Level;
        private System.Windows.Forms.Label LblSection;
        private System.Windows.Forms.TextBox TbxSection;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button BtnSave;
        private System.Windows.Forms.ComboBox CbxSuffix;
        private System.Windows.Forms.ComboBox CbxYear_Level;
        private System.Windows.Forms.ComboBox CbxGender;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem bACKToolStripMenuItem;
    }
}