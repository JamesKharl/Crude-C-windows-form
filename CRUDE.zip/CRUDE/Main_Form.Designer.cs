﻿namespace CRUDE
{
    partial class Main_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnAddStudent = new System.Windows.Forms.Button();
            this.BtnView = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // BtnAddStudent
            // 
            this.BtnAddStudent.BackColor = System.Drawing.Color.Black;
            this.BtnAddStudent.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.BtnAddStudent.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.BtnAddStudent.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.BtnAddStudent.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnAddStudent.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnAddStudent.ForeColor = System.Drawing.Color.Gold;
            this.BtnAddStudent.Location = new System.Drawing.Point(45, 108);
            this.BtnAddStudent.Name = "BtnAddStudent";
            this.BtnAddStudent.Size = new System.Drawing.Size(216, 59);
            this.BtnAddStudent.TabIndex = 0;
            this.BtnAddStudent.Text = "ADD STUDENT";
            this.BtnAddStudent.UseVisualStyleBackColor = false;
            this.BtnAddStudent.Click += new System.EventHandler(this.BtnAddStudent_Click);
            // 
            // BtnView
            // 
            this.BtnView.BackColor = System.Drawing.Color.Black;
            this.BtnView.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.BtnView.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.BtnView.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.BtnView.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnView.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnView.ForeColor = System.Drawing.Color.Gold;
            this.BtnView.Location = new System.Drawing.Point(45, 188);
            this.BtnView.Name = "BtnView";
            this.BtnView.Size = new System.Drawing.Size(216, 59);
            this.BtnView.TabIndex = 1;
            this.BtnView.Text = "VIEW";
            this.BtnView.UseVisualStyleBackColor = false;
            this.BtnView.Click += new System.EventHandler(this.BtnView_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(41, 52);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(236, 22);
            this.label1.TabIndex = 2;
            this.label1.Text = "STUDENT INFORMATION SYSTEM";
            // 
            // Main_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Cyan;
            this.ClientSize = new System.Drawing.Size(313, 347);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.BtnView);
            this.Controls.Add(this.BtnAddStudent);
            this.Name = "Main_Form";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtnAddStudent;
        private System.Windows.Forms.Button BtnView;
        private System.Windows.Forms.Label label1;
    }
}

